package it.polimi.ingsw2021;

public class PuntoND {
    private double[] coordinate;

    public PuntoND(double... coordinate) {
        this.coordinate = new double[coordinate.length];
        for (int i = 0; i < coordinate.length; i++) {
            this.coordinate[i] = coordinate[i];
        }
    }

    public double getCoordinata(int axis) {
        return this.coordinate[axis - 1];
    }

    public void setCoordinata(int axis, double coordinata) {
        this.coordinate[axis - 1] = coordinata;
    }

    public int getDimensioni() {
        return coordinate.length;
    }

    public double distanzaDa(PuntoND p) {
        double acc = 0.0;
        for (int i = 1; i <= this.getDimensioni(); i++) {
            acc += Math.pow(this.getCoordinata(i) - p.getCoordinata(i), 2);
        }
        return Math.sqrt(acc);
    }
}
