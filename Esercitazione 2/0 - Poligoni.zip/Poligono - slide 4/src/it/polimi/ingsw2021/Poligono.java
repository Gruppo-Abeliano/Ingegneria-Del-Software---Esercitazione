package it.polimi.ingsw2021;

public class Poligono {
    private PuntoND[] vertici;

    public Poligono(PuntoND[] vertici) {
//        this.vertici = vertici;
        this.vertici = new PuntoND[vertici.length];
        for (int i = 0; i < vertici.length; i++) {
            this.vertici[i] = vertici[i];
        }
    }

    public double getPerimetro() {
        double perimetro = 0.0;
        for (int i = 0; i < vertici.length; i++) {
            PuntoND a = vertici[i];
            PuntoND b = vertici[(i+1) % vertici.length];

            perimetro += b.distanzaDa(a);
        }
        return perimetro;
    }
}
