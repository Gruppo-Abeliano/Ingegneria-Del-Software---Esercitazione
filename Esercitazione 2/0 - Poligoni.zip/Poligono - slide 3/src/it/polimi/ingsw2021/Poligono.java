package it.polimi.ingsw2021;

public class Poligono {
    private double[][] vertici;

    public Poligono(double[][] vertici) {
        this.vertici = new double[vertici.length][];
        for (int i = 0; i < vertici.length; i++) {
            double[] vertice = vertici[i];
            this.vertici[i] = new double[vertice.length];
            for (int j = 0; j < vertice.length; j++) {
                this.vertici[i][j] = vertice[j];
            }
        }
    }

    public double getPerimetro() {
        double perimetro = 0.0;
        for (int i = 0; i < vertici.length; i++) {
            double[] a = vertici[i];
            double[] b = vertici[(i+1) % vertici.length];

            perimetro += Math.sqrt(Math.pow((b[0] - a[0]), 2) + Math.pow((b[1] - a[1]), 2));
        }
        return perimetro;
    }
}
