package it.polimi.ingsw2021;

public class Poligono {
    private PuntoND[] vertici;

    public Poligono(PuntoND[] vertici) {
        this.vertici = new PuntoND[vertici.length];
        for (int i = 0; i < vertici.length; i++) {
            PuntoND vertice = vertici[i];
            double[] coordinate = new double[vertice.getDimensioni()];
            for (int j = 1; j <= vertice.getDimensioni(); j++) {
                coordinate[j - 1] = vertice.getCoordinata(j);
            }
            this.vertici[i] = new PuntoND(coordinate);
        }
    }

    public void setVertice(int i, PuntoND p) {
        this.vertici[i] = p;
    }

    public double getPerimetro() {
        double perimetro = 0.0;
        for (int i = 0; i < vertici.length; i++) {
            PuntoND a = vertici[i];
            PuntoND b = vertici[(i+1) % vertici.length];

            perimetro += b.distanzaDa(a);
        }
        return perimetro;
    }
}
